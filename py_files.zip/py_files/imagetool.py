import cv2
import numpy as np
import os
from PIL import Image

def capture_image(cam, output_folder="DATA/TEMP"):
    os.makedirs(output_folder, exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc('M', 'J', 'P', 'G')
    cam.set(cv2.CAP_PROP_FOURCC, fourcc)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cam.set(cv2.CAP_PROP_FPS, 60)
    for _ in range(10):
        cam.read()
    ret, frame = cam.read()
    if not ret:
        print("Failed to grab frame")
        return None
    img_name = os.path.join(output_folder, "tempimg.jpg")
    cv2.imwrite(img_name, frame)
    # Sharpen
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharpened = cv2.filter2D(frame, -1, kernel)
    cv2.imwrite(img_name, sharpened)
    return img_name