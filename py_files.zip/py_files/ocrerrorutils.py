import os
from PIL import Image
import customtkinter
from customtkinter import CTkImage

def _load_scaled_image(path, max_w=820, max_h=420):
    try:
        im = Image.open(path)
        w, h = im.size
        scale = min(max_w / w, max_h / h, 1.0)
        im = im.resize((int(w*scale), int(h*scale)))
        return CTkImage(light_image=im, size=im.size)
    except Exception:
        # fallback: blank image
        im = Image.new("RGB", (min(max_w, 600), min(max_h, 300)), (30, 30, 30))
        return CTkImage(light_image=im, size=im.size)

def show_ocr_error_window(parent, err_type="MSMTCH", tempimg_path="DATA/TEMP/tempimg.jpg", preset_pin=""):
    """
    Opens a modal window to resolve OCR errors.
    - err_type: "MSMTCH" or "NOPIN"
    - tempimg_path: path to the captured image to display
    - preset_pin: optional prefill text
    After parent.wait_window(win), read win.result_pin ('' if user canceled)
    """
    win = customtkinter.CTkToplevel(parent)
    win.title("OCR Resolver — NoPIN / Mismatch")
    win.geometry("900x720")
    win.resizable(False, False)
    win.attributes('-topmost', True)
    win.configure(fg_color="#232121")

    # Make modal
    win.transient(parent)
    win.grab_set()
    win.grid_rowconfigure(0, weight=0)
    win.grid_columnconfigure(0, weight=1)

    # Header
    header = customtkinter.CTkLabel(
        win,
        text=f"OCR Error: {'No PIN Detected' if err_type.upper()=='NOPIN' else 'PIN Mismatch'}",
        font=customtkinter.CTkFont(family='Bahnschrift SemiLight', size=22, weight="bold"),
        text_color="#FFFFFF"
    )
    header.grid(row=0, column=0, padx=10, pady=30, sticky="nsew")

    # Image preview
    img_present = os.path.exists(tempimg_path)
    ctk_img = _load_scaled_image(tempimg_path)
    img_label = customtkinter.CTkLabel(win, text=None, image=ctk_img, corner_radius=10)
    img_label.grid(row=1, column=0, padx=10, pady=(0, 20), sticky="nsew")

    # Entry row
    entry_label = customtkinter.CTkLabel(
        win,
        text="Enter 7-digit PIN:",
        font=customtkinter.CTkFont(family='Bahnschrift SemiLight', size=16, weight="bold"),
        text_color="#E5E7EB",
    )
    entry_label.grid(row=2, column=0, padx=18, pady=(0, 10), sticky="nsew")

    entry_var = customtkinter.StringVar(value=str(preset_pin or ""))
    entry = customtkinter.CTkEntry(win, textvariable=entry_var, width=260, height=40, corner_radius=8)
    entry.grid(row=3, column=0, padx=18, pady=(0, 10), sticky="ns")

    # Status label (validation feedback)
    status_label = customtkinter.CTkLabel(
        win,
        text="" if img_present else f"Warning: missing image at {tempimg_path}",
        font=customtkinter.CTkFont(family='Bahnschrift SemiLight', size=12),
        text_color="#F59E0B" if not img_present else "#A3A3A3",
    )
    status_label.grid(row=4, column=0, padx=(0, 10), pady=(0, 2), sticky="nsew")

    # Result placeholder
    win.result_pin = ""

    # Buttons
    buttons_frame = customtkinter.CTkFrame(win, fg_color="transparent")
    buttons_frame.grid(row=5, column=0, padx=10, pady=(0, 30), sticky="nsew")
    buttons_frame.grid_propagate(False)
    # make left and right columns expand so the middle stays centered
    buttons_frame.grid_columnconfigure(0, weight=1)
    buttons_frame.grid_columnconfigure(2, weight=1)
    center_strip = customtkinter.CTkFrame(buttons_frame, fg_color="transparent")
    center_strip.grid(row=0, column=1, sticky="n")  # sits in the middle

    def on_confirm():
        val = (entry_var.get() or "").strip()
        # Keep digits only and enforce exactly 7 digits
        import re
        digits = re.sub(r"\D", "", val)
        if len(digits) != 7:
            status_label.configure(text="PIN must be exactly 7 digits.", text_color="#F87171")
            return
        win.result_pin = digits
        win.destroy()

    def on_cancel():
        win.result_pin = ""
        try:
            win.grab_release()          # important when using grab_set()
        except Exception:
            pass
        win.after(0, win.destroy)       # schedule safe destroy
    
    # Make the window's [X] (close) button act like Cancel
    win.protocol("WM_DELETE_WINDOW", on_cancel)

    # (optional) Press Esc to cancel too
    win.bind("<Escape>", lambda e: on_cancel())

    bt_cancel = customtkinter.CTkButton(center_strip, text="Cancel", fg_color="#4B5563", hover_color="#374151", command=on_cancel)
    bt_use    = customtkinter.CTkButton(center_strip, text="Use PIN & Continue", fg_color="#2563EB", hover_color="#1E40AF", command=on_confirm)

    bt_use.grid(row=0, column=0, padx=(0, 10))
    bt_cancel.grid(row=0, column=1, padx=(10, 0))

    entry.bind("<Return>", lambda e: on_confirm())  # press Enter to confirm
    win.bind("<Return>",  lambda e: on_confirm())  # also works even if focus is on the button
    
    # Focus
    entry.focus_set()

    return win