# models.py
import torch
import onnxruntime as ort
from . import ppneuralnet
from . import pputil

def load_yolo():
    print("Loading YOLO model 1...")
    model_path1 = r"DATA\YOLOonnx\pinregion.onnx"
    model = ort.InferenceSession(model_path1, providers = [
        "CUDAExecutionProvider",
        "CPUExecutionProvider",
    ])
    print("Loading YOLO model 2...")
    model_path1 = r"DATA\YOLOonnx\textbox.onnx"
    model2 = ort.InferenceSession(model_path1, providers = [
        "CUDAExecutionProvider",
        "CPUExecutionProvider",
    ])
    return model, model2

def load_ocr():
    detection = ppneuralnet.Detection(r'DATA\PPOCRonnxdet\PPOCRdet.onnx')
    recognition = ppneuralnet.Recognition(r'DATA\PPOCRonnxrec\PPOCRrec.onnx')
    return detection, recognition

def Load_rfdetr():
    print("Loading RFDETR model...")
    model_path = r"DATA\RFDETRonnx\rfdetr.onnx"
    model = ort.InferenceSession(model_path, providers = [
        "CUDAExecutionProvider",
        "CPUExecutionProvider",
    ])
    return model