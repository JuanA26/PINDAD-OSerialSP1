import cv2
import numpy

def sort_polygon(points, y_tol=10):
    # points: list of 4-pt polygons (each polygon is Nx1x2 or Nx2)
    # flatten to (4,2)
    pts = [numpy.array(p).reshape(-1, 2) for p in points]
    # sort by (rounded y bucket, then x)
    keyed = [((int(round(p[0,1]/y_tol)), int(p[0,0])), p) for p in pts]
    keyed.sort(key=lambda t: (t[0][0], t[0][1]))
    return [k[1] for k in keyed]


def crop_image(image, points):
    p = points.reshape(4, 2).astype(numpy.float32)
    w0 = numpy.linalg.norm(p[0] - p[1])
    w1 = numpy.linalg.norm(p[2] - p[3])
    h0 = numpy.linalg.norm(p[0] - p[3])
    h1 = numpy.linalg.norm(p[1] - p[2])
    cw, ch = int(max(w0, w1)), int(max(h0, h1))

    pts_std = numpy.float32([[0, 0], [cw, 0], [cw, ch], [0, ch]])
    M = cv2.getPerspectiveTransform(p, pts_std)
    out = cv2.warpPerspective(image, M, (cw, ch), borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_CUBIC)

    if (out.shape[0] / float(out.shape[1])) >= 1.5:
        out = numpy.rot90(out, k=3)
    return out

class CTCDecoder(object):
    def __init__(self):
        charset_path = r"C:\Users\norat\Desktop\KP\paddleonnxtest\ppocrv5_dict.txt"
        if charset_path is not None:
            with open(charset_path, "r", encoding="utf-8") as f:
                # Use rstrip to keep leading/trailing spaces on the line itself
                chars = [line.rstrip("\n") for line in f if line.rstrip("\n") != ""]
        else:
            print("No character set file provided, plase provide a source.")
        self.character = ["blank"] + chars

    def __call__(self, outputs):
        if isinstance(outputs, (tuple, list)):
            outputs = outputs[-1]
        indices = outputs.argmax(axis=2)
        return self.decode(indices, outputs)

    def decode(self, indices, outputs):
        results = []
        confidences = []
        ignored_tokens = [0]  # for ctc blank
        for i in range(len(indices)):
            selection = numpy.ones(len(indices[i]), dtype=bool)
            selection[1:] = indices[i][1:] != indices[i][:-1]
            for ignored_token in ignored_tokens:
                selection &= indices[i] != ignored_token
            result = []
            confidence = []
            for j in range(len(indices[i][selection])):
                result.append(self.character[indices[i][selection][j]])
                confidence.append(outputs[i][selection][j][indices[i][selection][j]])
            results.append(''.join(result))
            confidences.append(confidence)
        return results, confidences
