import serial
from serial.threaded import ReaderThread, LineReader
from serial.tools.list_ports import comports

class SerialReader(LineReader):
    port = None
    def __init__(self, app):
        super().__init__()
        self.app = app  # store reference to App instance

    def connection_made(self, transport):
        """Called when reader thread is started"""
        print("Connected, ready to receive data...")

    def handle_line(self, line):
        self.app.updateLabelData(line.encode())  # keep your existing function

def open_serial(port, baudrate=115200):
    """
    Open a serial port and return the serial.Serial object.
    """
    return serial.Serial(port=port, baudrate=baudrate, timeout=1)

def list_ports():
    """
    Returns a list of port objects, each with .device, .description, etc.
    """
    return list(comports())

def init_serial():
    return serial.Serial()