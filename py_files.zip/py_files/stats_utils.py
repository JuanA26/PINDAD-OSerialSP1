# stats_utils.py
import customtkinter
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import datetime

def show_statistics_window(parent, csv_file, tolerance):
    # Create new window
    new_window = customtkinter.CTkToplevel(parent)
    new_window.title("Statistics")
    new_window.geometry("900x700")
    new_window.attributes('-topmost', True)
    new_window.configure(fg_color='#232121')
    new_window.resizable(False, False)

    # --- Read today's data ---
    today = datetime.datetime.now().strftime('%Y-%m-%d')
    df = pd.read_csv(csv_file)
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    today_data = df[df['Timestamp'].dt.strftime('%Y-%m-%d') == today].copy()
    if today_data.empty:
        lbl = customtkinter.CTkLabel(new_window, text="No data found for today.", font=("Bahnschrift SemiLight", 20))
        lbl.pack(pady=30)
        return
    # --- Prepare the weight column as float ---
    today_data['Weight'] = pd.to_numeric(today_data['Weight'], errors='coerce')
    weights = today_data['Weight'].dropna()
    # --- Main statistics ---
    avg_weight = weights.mean()
    min_weight = weights.min()
    max_weight = weights.max()
    std_weight = weights.std()
    median_weight = weights.median()
    total = len(today_data)
    pass_count = today_data['Status'].str.contains("ACCEPTED").sum()
    reject_count = today_data['Status'].str.contains("REJECTED").sum()
    pass_rate = pass_count / total * 100
    reject_rate = reject_count / total * 100
    breakdown = {}
    reject_rows = today_data[today_data['Status'].str.contains("REJECTED")]
    for cause in ['LEAK TEST FAIL', 'MASS LOW', 'MASS HIGH', 'NOPIN', 'MSMTCH']:
        breakdown[cause] = reject_rows['Status'].str.contains(cause).sum()
    # --- Cp and Cpk calculation ---
    # Assuming spec limits are 5-tolerance to 5+tolerance (from your code)
    usl = 5 + tolerance
    lsl = 5 - tolerance
    cp = (usl - lsl) / (6 * std_weight) if std_weight > 0 else 0
    cpk = min((usl - avg_weight), (avg_weight - lsl)) / (3 * std_weight) if std_weight > 0 else 0
    # --- Stats summary string ---
    stat_str = (
        f"Total tanks processed: {total}\n"
        f"Average weight: {avg_weight:.3f} kg\n"
        f"Minimum weight: {min_weight:.3f} kg\n"
        f"Maximum weight: {max_weight:.3f} kg\n"
        f"Standard deviation: {std_weight:.4f}\n"
        f"Median weight: {median_weight:.3f} kg\n"
        f"\nPass rate: {pass_rate:.2f}% ({pass_count})\n"
        f"Reject rate: {reject_rate:.2f}% ({reject_count})\n"
        f"\nReject breakdown:\n" +
        "".join([f"  - {k}: {v}\n" for k, v in breakdown.items()]) +
        f"\nCp: {cp:.4f}\nCpk: {cpk:.4f}\n"
    )
    stat_label = customtkinter.CTkTextbox(new_window, width=600, height=320)
    stat_label.insert("1.0", stat_str)
    stat_label.configure(state="disabled", font=("Consolas", 14))
    stat_label.pack(pady=12, padx=8)
    # --- Moving average plot (real-time trend) ---
    fig, ax = plt.subplots(figsize=(7, 3.2), dpi=100, facecolor='#232121')
    ax.set_title('Moving Average of Weight (up to 3000 tanks)', color='white')
    ax.set_xlabel('Tank Number', color='white')
    ax.set_ylabel('Weight (kg)', color='white')
    # Set tick color to white (for both axes)
    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')
    window_size = 50  # Change as you like
    weights_sorted = weights.reset_index(drop=True)
    moving_avg = weights_sorted.rolling(window=window_size, min_periods=1).mean()
    ax.plot(weights_sorted.index + 1, weights_sorted, label="Weight", alpha=0.4)
    ax.plot(weights_sorted.index + 1, moving_avg, label=f"{window_size}-Tank Moving Avg", color='orange', linestyle=':')
    ax.axhline(usl, color='red', linestyle='--', linewidth=1, label='USL/LSL')
    ax.axhline(lsl, color='red', linestyle='--', linewidth=1)
    ax.legend()
    ax.grid(True, linestyle='--', alpha=0.4)
    # Integrate matplotlib plot into Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=new_window)
    canvas.draw()
    canvas.get_tk_widget().pack(padx=10, pady=10, fill='both', expand=True)
    plt.close(fig)  # Prevents new matplotlib window popping up
