import os, shutil, requests, zipfile, io, tempfile
from . import globals

def download_with_progress(url, desc="Downloading"):
    import sys
    import time

    response = requests.get(url, stream=True)
    total_length = response.headers.get('content-length')

    if total_length is None:  # no content length header
        content = response.content
        print(f"{desc}: Size unknown. Downloaded.")
        return content

    total_length = int(total_length)
    chunk_size = 8192
    downloaded = 0
    chunks = []
    start_time = time.time()
    print(f"{desc}:")
    for chunk in response.iter_content(chunk_size=chunk_size):
        if chunk:
            chunks.append(chunk)
            downloaded += len(chunk)
            done = int(50 * downloaded / total_length)
            percent = int(100 * downloaded / total_length)
            speed = downloaded / (time.time() - start_time + 1e-5)
            sys.stdout.write(
                f"\r[{'=' * done}{' ' * (50 - done)}] {percent}% "
                f"{downloaded//1024}KB/{total_length//1024}KB "
                f"({speed/1024:.1f} KB/s)"
            )
            sys.stdout.flush()
    sys.stdout.write("\n")
    return b"".join(chunks)

def download_and_merge_data(folder_names, base_url, target_dir="DATA"):
    import tempfile
    os.makedirs(target_dir, exist_ok=True)
    for folder in folder_names:
        zip_url = f"{base_url}/{folder}.zip"
        print(f"Preparing to download {folder} from {zip_url}...")
        try:
            # Use the custom download_with_progress function
            content = download_with_progress(zip_url, desc=f"Downloading {folder}")
            if content and len(content) > 0:
                with zipfile.ZipFile(io.BytesIO(content)) as zip_ref:
                    with tempfile.TemporaryDirectory() as temp_extract_dir:
                        zip_ref.extractall(temp_extract_dir)
                        for extracted_name in os.listdir(temp_extract_dir):
                            src_path = os.path.join(temp_extract_dir, extracted_name)
                            dest_path = os.path.join(target_dir, folder)
                            if os.path.isdir(src_path):
                                if os.path.exists(dest_path):
                                    shutil.rmtree(dest_path)
                                shutil.move(src_path, dest_path)
                                print(f"Extracted into: {dest_path}")
            else:
                print(f"Failed to download {zip_url}: No content received.")
        except Exception as e:
            print(f"Error downloading {folder}: {e}")
    pass

def check_and_restore_data():
    github_zip_base_url = "https://raw.githubusercontent.com/JuanA26/PINDAD-OSerialSP1/main"  # <- EDIT IF NEEDED
    required_subfolders = ["images", "TEMP"]

    missing = []
    if not os.path.isdir(globals.folder_data):
        print(f"'{globals.folder_data}' folder is missing.")
        missing = required_subfolders
    else:
        # Check if all required subfolders exist inside DATA
        for sub in required_subfolders:
            sub_path = os.path.join(globals.folder_data, sub)
            if not os.path.isdir(sub_path):
                print(f"Missing subfolder: {sub_path}")
                missing.append(sub)

    if missing:
        print(f"Downloading missing folders: {missing}")
        download_and_merge_data(missing, github_zip_base_url)
    else:
        print(f"'{globals.folder_data}' and all required subfolders are present.")
    pass